package com.example.notification_t1;

import android.app.Activity;
import android.content.Context;
import android.view.View;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class fcmNotificationSender  {

    String userFcmToken;
    String title;
    String body;
    Context mContext;
    Activity mActivity;

    // the postUrl will be same 
    private final String postUrl = "https://fcm.googleapis.com/fcm/send";
    //fcmServerKey must be replaced with priyal's code 
    private final String fcmServerKey ="AAAAkmfHssw:APA91bFQbZ66LqCirm6wEcxCX3nAUAOOqx5Dmd6Db4LXZo-QxeDcfguxdfKKScjDMfKEyy3sRoUV_dVHuo6NQxGbXKXs6DeeLKxdXnyiUdmXhnZeC3y30aiE-eNmMzvvAXRaEX9_knYh";

    public fcmNotificationSender(String userFcmToken, String title, String body, Context mContext, Activity mActivity) {
        this.userFcmToken = userFcmToken;
        this.title = title;
        this.body = body;
        this.mContext = mContext;
        this.mActivity = mActivity;


    }

    public void SendNotifications() {

        RequestQueue requestQueue = Volley.newRequestQueue(mActivity);
        JSONObject mainObj = new JSONObject();
        try {
            mainObj.put("to", userFcmToken);
            JSONObject notiObject = new JSONObject();
            notiObject.put("title", title);
            notiObject.put("body", body);
            notiObject.put("icon", "R.drawable.ic_baseline_notifications_active_24");// if there is an icon disgned then you are going to place it here 
             // enter icon that exists in drawable only



            mainObj.put("notification", notiObject);


            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, postUrl, mainObj, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                    // code run is got response

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // code run is got error

                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {


                    Map<String, String> header = new HashMap<>();
                    header.put("content-type", "application/json");
                    header.put("authorization", "key=" + fcmServerKey);
                    return header;


                }//sending the request 
            };
            requestQueue.add(request);


        } catch (JSONException e) {
            e.printStackTrace();
        }




    }
}